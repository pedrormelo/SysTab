const db = require('../config/db');

exports.criarChamado = (req, res) => {
    let

}